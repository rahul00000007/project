package com.BusReservation.model;

public class TransactionDetails {
	private String source;
	private String destination;
}
