package com.lnt.mvc.service;

import javax.transaction.Transactional;

import com.lnt.mvc.dao.RegistrationDao;
import com.lnt.mvc.model.Registration;

public class RegistrationServiceImpl implements RegistrationService {
	
	private RegistrationDao registrationDao;

	public void setRegistrationDao(RegistrationDao registrationDao) {
		this.registrationDao = registrationDao;
	}

	@Override
	@Transactional
	public void save(Registration r) {
		this.registrationDao.save(r);
		
	}
	

}
