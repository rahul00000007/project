package com.lnt.mvc.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.lnt.mvc.model.Registration;

public class RegistrationDaoImpl implements RegistrationDao {

	
		private static final Logger logger = 			
				LoggerFactory.getLogger(RegistrationDaoImpl.class);

		private SessionFactory sessionFactory;
		
		@Autowired
		public void setSessionFactory(SessionFactory sf) {
			this.sessionFactory = sf;
		}
		@Override
		public void save(Registration r) {
			
			Session session = this.sessionFactory.openSession();
			session.persist(r);
			logger.info("Person saved successfully, Person Details="
			+ r);
			session.close();
			
			
	}

}
