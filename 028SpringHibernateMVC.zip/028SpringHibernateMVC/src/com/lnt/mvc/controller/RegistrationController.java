package com.lnt.mvc.controller;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lnt.mvc.exception.CustomException;
//import com.lnt.mvc.model.Person;
import com.lnt.mvc.model.Registration;
import com.lnt.mvc.service.RegistrationService;

@Controller
public class RegistrationController {
	
private RegistrationService registrationService;


@Autowired
@Qualifier(value="registrationService")
public void setRegistrationService(RegistrationService registrationService) {
	this.registrationService = registrationService;
}

@ExceptionHandler(CustomException.class)
public ModelAndView handlePersonNotFoundException(CustomException ex) {
	Map<String, CustomException> model = new HashMap<String, CustomException>();
	model.put("exception", ex);
	return new ModelAndView("error", model);

}

@ExceptionHandler(Exception.class)
public ModelAndView handleException(Exception ex) {
	Map<String, Exception> model = new HashMap<String, Exception>();
	model.put("exception", ex);
	return new ModelAndView("error", model);

}

@RequestMapping(value = "/institutes", 
method = RequestMethod.POST)
@ExceptionHandler({ CustomException.class })
public String save(
		@ModelAttribute("institute") 
		@Valid Registration r, 
		BindingResult result, 
		Model model) {
	
	if (result.hasErrors()) {
		if (r.getIn_Code()==null) {
			// new person, add it
			this.registrationService.save(r);
		} else {
			return "redirect:/institutes";	 
		}
		
	}
	return "institute";
		
	}
		@RequestMapping("/showErrorPage/error")
		@ExceptionHandler(Exception.class)
		public ModelAndView exception(Exception e) {

			ModelAndView mav = new ModelAndView("error");// view name
			mav.addObject("exName", e.getClass().getSimpleName());// model for ex name
			mav.addObject("exMessage", e.getMessage());// model for ex msg
			return mav;
		}
}		
		


	
	
	
			




